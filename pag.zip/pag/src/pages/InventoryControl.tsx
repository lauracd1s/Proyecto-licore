import React from 'react';
import { Package, TrendingDown, AlertTriangle } from 'lucide-react';

const InventoryControl: React.FC = () => {
  // Leer productos desde localStorage
  const [products, setProducts] = React.useState<any[]>([]);

  React.useEffect(() => {
    const stored = localStorage.getItem('products');
    if (stored) {
      const parsed = JSON.parse(stored).map((p: any) => ({
        ...p,
        createdAt: p.createdAt ? new Date(p.createdAt) : undefined
      }));
      setProducts(parsed);
    }
  }, []);

  const lowStockProducts = products.filter(p => p.stock <= p.minStock);
  const outOfStockProducts = products.filter(p => p.stock === 0);
  const totalInventoryValue = products.reduce((total, p) => total + (p.stock * p.cost), 0);

  return (
    <div className="inventory-control">
      <div className="page-header">
        <h1 className="page-title">
          <Package size={28} />
          Control de Inventario
        </h1>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">${totalInventoryValue.toFixed(2)}</div>
          <div className="stat-label">Valor Total del Inventario</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{products.reduce((total, p) => total + p.stock, 0)}</div>
          <div className="stat-label">Total Unidades en Stock</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{lowStockProducts.length}</div>
          <div className="stat-label">Productos con Stock Bajo</div>
          <div className="stat-growth negative">
            <TrendingDown size={16} />
            Requieren reabastecimiento
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{outOfStockProducts.length}</div>
          <div className="stat-label">Productos Sin Stock</div>
          <div className="stat-growth negative">
            <AlertTriangle size={16} />
            Atención inmediata
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Estado del Inventario por Producto</h3>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Stock Actual</th>
                <th>Stock Mínimo</th>
                <th>Estado</th>
                <th>Valor en Stock</th>
              </tr>
            </thead>
            <tbody>
              {products.map(product => {
                const isLowStock = product.stock <= product.minStock;
                const isOutOfStock = product.stock === 0;
                return (
                  <tr key={product.id}>
                    <td>
                      <div>
                        <div style={{ fontWeight: '600' }}>{product.name}</div>
                        <div style={{ fontSize: '0.8rem', color: '#666' }}>
                          {product.brand} - {product.category}
                        </div>
                      </div>
                    </td>
                    <td style={{ fontWeight: '600' }}>
                      {product.stock} unidades
                    </td>
                    <td>{product.minStock} unidades</td>
                    <td>
                      {isOutOfStock ? (
                        <span className="badge badge-danger">Sin Stock</span>
                      ) : isLowStock ? (
                        <span className="badge badge-warning">Stock Bajo</span>
                      ) : (
                        <span className="badge badge-success">Stock OK</span>
                      )}
                    </td>
                    <td style={{ fontWeight: '600' }}>
                      ${(product.stock * product.cost).toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default InventoryControl;
