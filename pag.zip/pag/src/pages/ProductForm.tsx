import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, ArrowLeft, Package } from 'lucide-react';
import type { ProductDisplay } from '../types';

const ProductForm: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  // Estado para productos desde localStorage
  const [products, setProducts] = useState<ProductDisplay[]>([]);
  const isEdit = Boolean(id);

  const [formData, setFormData] = useState({
    name: '',
    category: 'whisky' as ProductDisplay['category'],
    brand: '',
    price: 0,
    cost: 0,
    stock: 0,
    minStock: 0,
    image: '',
    description: '',
    alcoholContent: 0,
    volume: 750,
    barcode: '',
    isActive: true
    , expirationDate: ''
  });

  // Cargar productos al montar
  useEffect(() => {
    const stored = localStorage.getItem('products');
    if (stored) {
      setProducts(JSON.parse(stored));
    }
  }, []);

  // Si editando, cargar datos del producto
  useEffect(() => {
    if (isEdit && id && products.length) {
      const product = products.find(p => p.id === id);
      if (product) {
        setFormData({
          name: product.name,
          category: product.category,
          brand: product.brand,
          price: product.price,
          cost: product.cost,
          stock: product.stock,
          minStock: product.minStock,
          image: product.image,
          description: product.description,
          alcoholContent: product.alcoholContent,
          volume: product.volume,
          barcode: product.barcode,
          isActive: product.isActive
            , expirationDate: product.expirationDate || ''
        });
      }
    }
  }, [isEdit, id, products]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let updatedProducts = [...products];
    if (isEdit && id) {
      // Actualizar producto existente
      updatedProducts = updatedProducts.map(p =>
        p.id === id ? { ...p, ...formData, id } : p
      );
    } else {
      // Agregar nuevo producto
      const newId = Date.now().toString();
      updatedProducts.push({
        ...formData,
        id: newId,
        createdAt: new Date()
      });
    }
    localStorage.setItem('products', JSON.stringify(updatedProducts));
    setProducts(updatedProducts);
    navigate('/products');
  };

  const categories = [
    'whisky', 'vodka', 'ron', 'gin', 'cerveza', 'vino', 'licor', 'otros'
  ];

  return (
    <div className="product-form">
      <div className="page-header">
        <h1 className="page-title">
          <Package size={28} />
          {isEdit ? 'Editar Producto' : 'Agregar Producto'}
        </h1>
        <button onClick={() => navigate('/products')} className="btn btn-outline">
          <ArrowLeft size={20} />
          Volver
        </button>
      </div>

      <div className="card">
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div>
              <h3 style={{ marginBottom: '1.5rem', color: '#8B4513' }}>Información Básica</h3>
              
              <div className="form-group">
                <label className="form-label">Nombre del Producto *</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label className="form-label">Categoría *</label>
                  <select
                    className="form-select"
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value as ProductDisplay['category'] }))}
                    required
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Marca *</label>
                  <input
                    type="text"
                    className="form-input"
                    value={formData.brand}
                    onChange={(e) => setFormData(prev => ({ ...prev, brand: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Descripción</label>
                <textarea
                  className="form-textarea"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Código de Barras</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.barcode}
                  onChange={(e) => setFormData(prev => ({ ...prev, barcode: e.target.value }))}
                />
              </div>

                <div className="form-group">
                  <label className="form-label">Fecha de Vencimiento</label>
                  <input
                    type="date"
                    className="form-input"
                    value={formData.expirationDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, expirationDate: e.target.value }))}
                  />
                </div>

              <div className="form-group">
                <label className="form-label">URL de Imagen</label>
                <input
                  type="url"
                  className="form-input"
                  value={formData.image}
                  onChange={(e) => setFormData(prev => ({ ...prev, image: e.target.value }))}
                />
              </div>

              <div className="form-group">
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <input
                    type="checkbox"
                    checked={formData.isActive}
                    onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                  />
                  <span className="form-label" style={{ marginBottom: 0 }}>Producto activo</span>
                </label>
                <small style={{ color: '#666', fontSize: '0.8rem', marginLeft: '1.5rem' }}>
                  Solo los productos activos aparecen en el catálogo
                </small>
              </div>
            </div>

            <div>
              <h3 style={{ marginBottom: '1.5rem', color: '#8B4513' }}>Precios e Inventario</h3>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label className="form-label">Precio de Venta *</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: Number(e.target.value) }))}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Costo *</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={formData.cost}
                    onChange={(e) => setFormData(prev => ({ ...prev, cost: Number(e.target.value) }))}
                    required
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label className="form-label">Stock Actual *</label>
                  <input
                    type="number"
                    className="form-input"
                    value={formData.stock}
                    onChange={(e) => setFormData(prev => ({ ...prev, stock: Number(e.target.value) }))}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Stock Mínimo *</label>
                  <input
                    type="number"
                    className="form-input"
                    value={formData.minStock}
                    onChange={(e) => setFormData(prev => ({ ...prev, minStock: Number(e.target.value) }))}
                    required
                  />
                </div>
              </div>

              <h3 style={{ margin: '2rem 0 1.5rem', color: '#8B4513' }}>Especificaciones</h3>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label className="form-label">Volumen (ml) *</label>
                  <input
                    type="number"
                    className="form-input"
                    value={formData.volume}
                    onChange={(e) => setFormData(prev => ({ ...prev, volume: Number(e.target.value) }))}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Graduación Alcohólica (%) *</label>
                  <input
                    type="number"
                    step="0.1"
                    className="form-input"
                    value={formData.alcoholContent}
                    onChange={(e) => setFormData(prev => ({ ...prev, alcoholContent: Number(e.target.value) }))}
                    required
                  />
                </div>
              </div>

              <div style={{ 
                marginTop: '2rem',
                padding: '1rem',
                backgroundColor: '#F5F5DC',
                borderRadius: '8px'
              }}>
                <h4 style={{ color: '#8B4513', marginBottom: '0.5rem' }}>Margen de Ganancia</h4>
                <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#8B4513' }}>
                  {formData.price && formData.cost 
                    ? `${(((formData.price - formData.cost) / formData.cost) * 100).toFixed(1)}%`
                    : '0%'
                  }
                </div>
                <div style={{ fontSize: '0.9rem', color: '#666' }}>
                  Ganancia por unidad: ${(formData.price - formData.cost).toFixed(2)}
                </div>
              </div>
            </div>
          </div>

          <div style={{ 
            display: 'flex', 
            gap: '1rem', 
            justifyContent: 'flex-end',
            marginTop: '2rem',
            paddingTop: '1rem',
            borderTop: '1px solid #E0E0E0'
          }}>
            <button 
              type="button" 
              onClick={() => navigate('/products')}
              className="btn btn-outline"
            >
              Cancelar
            </button>
            <button type="submit" className="btn btn-primary">
              <Save size={20} />
              {isEdit ? 'Actualizar Producto' : 'Guardar Producto'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProductForm;
